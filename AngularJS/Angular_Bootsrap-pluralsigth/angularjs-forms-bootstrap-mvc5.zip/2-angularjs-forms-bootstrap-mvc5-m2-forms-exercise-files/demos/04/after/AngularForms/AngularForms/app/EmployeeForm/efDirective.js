﻿
angularFormsApp.directive('employeeForm',
    function () {

        return {
            restrict: 'E',
            templateUrl: 'app/EmployeeForm/efTemplate.html'
        }

    });