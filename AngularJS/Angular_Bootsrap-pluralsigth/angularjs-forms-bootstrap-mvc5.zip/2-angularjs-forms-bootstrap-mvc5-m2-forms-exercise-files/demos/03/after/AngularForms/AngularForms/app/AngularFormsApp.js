﻿
var angularFormsApp = angular.module('angularFormsApp', []);

