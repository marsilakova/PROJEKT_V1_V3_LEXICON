﻿
var testButton = document.getElementById('testButton');
testButton.onclick = function () {
    alert("Coffee added to your cart");
}